import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Main2 {
    public static void main(String[] args) {
        ClassContainer container = new ClassContainer();

        ClassEmployee group1 = new ClassEmployee("Grupa 1", 10);
        ClassEmployee group2 = new ClassEmployee("Grupa 2", 15);
        ClassEmployee group3 = new ClassEmployee("Grupa 3", 12);

        container.addClass(group1.getGroupName(), group1.getMaxValue());
        container.addClass(group2.getGroupName(), group2.getMaxValue());
        container.addClass(group3.getGroupName(), group3.getMaxValue());

        Employee employee1 = new Employee("Adam", "Nowak", EmployeeCondition.OBECNY, 1998, 4500);
        Employee employee2 = new Employee("Mateusz", "Kowalczyk", EmployeeCondition.CHORY, 1987, 5500);
        Employee employee3 = new Employee("Jakub", "Wrona", EmployeeCondition.OBECNY, 1990, 5200);
        Employee employee4 = new Employee("Aleksander", "Nowakowski", EmployeeCondition.NIEOBECNY, 1977, 6100);
        Employee employee5 = new Employee("Alicja", "Sikora", EmployeeCondition.OBECNY, 1988, 5000);
        Employee employee6 = new Employee("Olga", "Stefaniuk", EmployeeCondition.OBECNY, 1987, 5000);



        group1.addEmployee(employee1);
        group2.addEmployee(employee2);
        group1.addEmployee(employee3);
        group2.addEmployee(employee4);
        group1.addEmployee(employee5);
        group2.addEmployee(employee6);


        //group1.addSalary(employee1,500);
        //group2.changeCondition(employee2,EmployeeCondition.DELEGACJA);
        // group1.removeEmployee(employee1);


        Employee foundEmployee = group2.search("Kowalczyk");
        if (foundEmployee != null) {
            foundEmployee.printing();
        } else {
            System.out.println("Nie znaleziono pracownika o podanym nazwisku");
        }

        long count = group1.countByCondition(EmployeeCondition.OBECNY);
        System.out.println("Liczba pracownikow w grupie 1 z warunkiem 'OBECNY': " + count);

//        Employee employee = group1.max(employeeList);
//        System.out.println(employee);

        List<Employee> salaryDisplayGroup1 = group1.sortBySalary(group1.getEmployeeList());
        System.out.println("Grupa 1 - Pracownicy posortowani wedlug wynagrodzenia:");
        for (Employee employee : salaryDisplayGroup1) {
            System.out.println(employee.getLastName() + " - " + employee.getSalary());
        }

//        List<Employee> salaryDisplayGroup2 = group2.sortBySalary(group2.getEmployeeList());
//        System.out.println("Grupa 2 - Pracownicy posortowani według wynagrodzenia:");
//        for (Employee employee : salaryDisplayGroup2) {
//            System.out.println(employee.getLastName() + " - " + employee.getSalary());
//        }


        container.summary();
        container.findEmpty();
        group3.displayEmployees(group3);
    }
}

