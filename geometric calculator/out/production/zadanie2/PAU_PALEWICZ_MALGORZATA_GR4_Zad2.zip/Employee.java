public class Employee implements Comparable<Employee> {
    private final String firstName;
    private final String lastName;
    private EmployeeCondition employeeCondition;
    private final int birthYear;
    private double salary;

    public Employee (String firstName, String lastName, EmployeeCondition employeeCondition, int birthYear, double salary){
        this.firstName = firstName;
        this.lastName = lastName;
        this.employeeCondition = employeeCondition;
        this.birthYear = birthYear;
        this.salary = salary;
    }

    public String getFirstName() {return firstName;}
    public String getLastName() {return lastName;}
    public EmployeeCondition getEmployeeCondition() {return employeeCondition;}
    public double getSalary() {return salary;}
    public int getBirthYear() {return birthYear;}

    public void setSalary(double salary) {this.salary = salary;}
    public void setEmployeeCondition(EmployeeCondition employeeCondition) {this.employeeCondition = employeeCondition;}

    void printing(){
        System.out.println("Pracownik " + firstName + " " + lastName + " urodzony w " + birthYear + " zarabia " + salary);
    }

    @Override
    public int compareTo(Employee anotherEmployee) {
        // 0 - obecny, 0 < jest po drugim obiekcie, 0 > przed drugim obiektem
//        int name = this.firstName.compareTo(anotherEmployee.firstName);
//        if(name != 0){
//            return name;
//        }
        //sprawdzenie tylko naziwska
        return this.lastName.compareTo(anotherEmployee.lastName);
    }

    @Override
    public String toString() {
        return "Pracownik " + firstName + " " + lastName + " urodzony w " + birthYear + " zarabia " + salary;
    }

}
