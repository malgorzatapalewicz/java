import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClassContainer {
    private Map<String, ClassEmployee> groupMap;
    public ClassContainer(){
        groupMap = new HashMap<>();
    }

    public Map<String, ClassEmployee> getGroupMap() {return groupMap;}

    public void addClass(String name, int size){
        if(groupMap.containsKey(name)){
            System.out.println("Grupa pracownicza " + name + " juz istnieje");
            return;
        }
        ClassEmployee newGroup = new ClassEmployee(name, size);
        groupMap.put(name, newGroup);
    }


    public void removeClass(String name){
        if(!(groupMap.containsKey(name))){
            System.out.println("Grupa pracownicza " + name + " nie istnieje");
            return;
        }
        groupMap.remove(name);
        System.out.println("Grupa pracownicza " + name + " zostala usunieta");
    }

    public void findEmpty() {
        List<String> emptyGroups = new ArrayList<>();
        for(Map.Entry<String, ClassEmployee> entry : groupMap.entrySet()) {
            if(entry.getValue().getEmployeeList().isEmpty()){
                System.out.println(entry.getKey() + " jest pusta");
            }
        }
    }

    public void summary() {
        System.out.println("Podsumowanie:");
        for (Map.Entry<String, ClassEmployee> entry : groupMap.entrySet()) {
            String groupName = entry.getKey();
            ClassEmployee group = entry.getValue();
            int size = group.getMaxValue();
            int filledPercentage = (int) (((double) group.getEmployeeList().size() / size) * 100);
            System.out.println("Grupa pracownicza " + groupName + " jest wypełniona w " + filledPercentage + "%");
        }
    }

}
