public enum EmployeeCondition {
    OBECNY, DELEGACJA, CHORY, NIEOBECNY;
}
