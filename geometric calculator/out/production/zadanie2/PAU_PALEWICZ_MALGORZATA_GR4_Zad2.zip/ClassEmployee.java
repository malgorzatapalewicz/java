import java.util.*;
import java.util.stream.Collectors;

public class ClassEmployee{
    private final String groupName;
    private final List<Employee> employeeList;
    private final int maxValue;

    public String getGroupName() {return groupName;}

    public int getMaxValue() {return maxValue;}

    public ClassEmployee(String groupName, int maxValue){
        this.groupName = groupName;
        this.maxValue = maxValue;
        this.employeeList = new ArrayList<Employee>();
    }

    public List<Employee> getEmployeeList() {return employeeList;}
    public boolean isEmployeeListEmpty(){
        return employeeList.isEmpty();
    }
    public boolean ifEmployeeInList(Employee employeeToFind){
        for(Employee employee : employeeList){
            if(employee.compareTo(employeeToFind) == 0) return true;
        }
        return false;
    }
    public void addEmployee(Employee newEmployee){
        if(isEmployeeListEmpty()){
            employeeList.add(newEmployee);
            return;
        }
        if(ifEmployeeInList(newEmployee)){
            System.out.println(newEmployee.getFirstName() + " " + newEmployee.getLastName() + " juz tu pracuje");
            return;
        }
        if (employeeList.size() >= maxValue){
            System.out.println("Grupa jest juz pelna, nie mozna dodac pracownika");
            return;
        }
        employeeList.add(newEmployee);
    }
    public void addSalary(Employee employee, double amount){
        if(!(ifEmployeeInList(employee))){
            System.out.println("Pracownik dla ktorego chcesz zmienic pensje nie istnieje");
            return;
        }
        employee.setSalary(employee.getSalary() + amount);
        System.out.println("Pensja Pana/Pani " + employee.getLastName() + " po zmianie wynosi " + employee.getSalary());
    }
    public void removeEmployee(Employee employee){
        if(isEmployeeListEmpty()){
            System.out.println("Grupa jest pusta, nie ma jak usunac pracownika");
            return;
        }
        if(!(ifEmployeeInList(employee))){
            System.out.println("Pracownik dla ktorego chcesz zmienic pensje nie istnieje");
            return;
        }
        employeeList.remove(employee);
    }
    public void changeCondition(Employee employee, EmployeeCondition employeeCondition){
        if(!(ifEmployeeInList(employee))){
            System.out.println("Pracownik dla ktorego chcesz zmienic stan nie istnieje");
            return;
        }
        System.out.print("Stan pracownika " + employee.getEmployeeCondition());
        employee.setEmployeeCondition(employeeCondition);
        System.out.println(" zmieniono na " + employee.getEmployeeCondition());
    }
    public Employee search(String lastName){
        //komperator porownujacy nazwiska
        Comparator<String> lastNameComparator = Comparator.naturalOrder(); //porownuje leksygraficznie

        for(Employee employee : employeeList){
            if (lastNameComparator.compare(employee.getLastName(), lastName) == 0) {
                return employee;
            }
        }
            return null;
    }

    public List<Employee> searchPartial(String partName){
        return employeeList.stream()
                .filter(employee -> employee.getLastName().contains(partName) || employee.getFirstName().contains(partName)) //contains zwraca true albo false
                .toList();
    }

    public long countByCondition(EmployeeCondition employeeCondition){ //stream nie zwraca int tylko long
        return employeeList.stream()
                .filter(employee -> employee.getEmployeeCondition() == employeeCondition)
                .count();
    }

    public void summary(List<Employee> employeeList){
         employeeList.forEach(Employee::printing); //referencja
    }

    public List<Employee> sortByName(List<Employee> employeeList){
        List<Employee> sortedList = new ArrayList<>(employeeList); //tworzenie kopii oryginalnej listy
        Comparator<Employee> comparator = Comparator
                .comparing(Employee::getLastName)
                .thenComparing(Employee::getFirstName);
        Collections.sort(sortedList, comparator);
        return sortedList;
    }

    public List<Employee> sortBySalary(List<Employee> employeeList){
        return employeeList.stream()
                .sorted(Comparator.comparingDouble(Employee::getSalary).reversed())
                .collect(Collectors.toList());
    }

    public Employee max(List<Employee> employeeList){
        if (employeeList.isEmpty()) {
            throw new IllegalArgumentException("Lista pracownikow jest pusta");
        }
       return Collections.max(employeeList, Comparator
               .comparingDouble(Employee::getSalary)
               .thenComparing(Employee::getBirthYear).reversed());
    }

    public void displayEmployees(ClassEmployee group) {
        System.out.println(group.getGroupName() + ": ");
        for (Employee employee : group.getEmployeeList()) {
            employee.printing();
        }
    }
}
